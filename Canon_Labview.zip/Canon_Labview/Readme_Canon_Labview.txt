----------------------------------------------------------------------------

This Labview software is based on Canon EDSDK 

----------------------------------------------------------------------------
Contents
Labview Project (CanonEOS)
TakePicture.vi
	With this vi, you can click camera shutter using Labview
ExposureData.vi
	With this vi, you can obtain camera exposure info using Labview.
	This was intended to change exposure setting with Labview.
	